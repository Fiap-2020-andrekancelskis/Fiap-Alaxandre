package br.com.fiap.estoque;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.estoque.EstoqueBasicoStub.Soma;
import br.com.fiap.estoque.EstoqueBasicoStub.SomaResponse;

public class ConsultaBasica {

	
		 public static void main(String[] args) {
			
			 try {
				 
				 //Classe stub.
				 EstoqueBasicoStub ebs = new EstoqueBasicoStub();
				 
				 //classe com nome do metodo.
				 Soma sm = new Soma();
				 sm.setNr1(100);
				 sm.setNr2(23);
				 
				 //stub recebendo o paramentro ja retornando para a response.
				 SomaResponse smr =	 ebs.soma(sm);
				 
				 //response retornando o OBJ resultando.
				 System.out.println("O resultado da opera��o �: " + smr.get_return());
				
			} catch (AxisFault e) {
				e.printStackTrace();
			}catch (RemoteException e) {
				e.printStackTrace();
			}
			 
		}
}
