package br.com.fiap.listar;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

import br.com.fiap.listar.ListarStub.Listar;
import br.com.fiap.listar.ListarStub.ListarResponse;

public class Consumir {

	public static void main(String[] args) {

		try {
			ListarStub ls = new ListarStub();
			
			Listar l = new Listar();
			l.setCodigo(10);
			
			ListarResponse lr = ls.listar(l);
			
			System.out.println("Codigo: "+ lr.get_return());
			
			
		} catch (AxisFault e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("\n DEU RUIM NO AXIS \n");
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("\n DEU RUIM == \n");
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("\n DEU ERRO GENERICO \n");
		}
		
		
		
	}

}
