package br.com.fiap.listar;

public class Listar {

	public int listar(int codigo) {
		return codigo;
	}
}
