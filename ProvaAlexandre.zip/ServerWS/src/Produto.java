
public class Produto {
	public int listar(int codigo) {
		return codigo;
	}
}
