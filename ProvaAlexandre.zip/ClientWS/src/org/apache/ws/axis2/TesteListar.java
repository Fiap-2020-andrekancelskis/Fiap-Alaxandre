package org.apache.ws.axis2;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;
import org.apache.ws.axis2.ProdutoStub.Listar;
import org.apache.ws.axis2.ProdutoStub.ListarResponse;

public class TesteListar {

	public static void main(String[] args) {
		try {
			ProdutoStub stub = new ProdutoStub();
			Listar l = new Listar();
			l.setCodigo(1); 
			
			ListarResponse lr = stub.listar(l); 
			System.out.println("Listar: "+lr.get_return());
			
		} catch (AxisFault e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		

	}

}
