package org.apache.ws.servlets;

import java.io.IOException;
import java.rmi.RemoteException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.axis2.AxisFault;
import org.apache.ws.axis2.ProdutoStub;
import org.apache.ws.axis2.ProdutoStub.Listar;
import org.apache.ws.axis2.ProdutoStub.ListarResponse;

@WebServlet(urlPatterns = "/listar")
public class ServletListar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String codigo = req.getParameter("codigo");
		try {
			ProdutoStub stub = new ProdutoStub();
			Listar l = new Listar();
			l.setCodigo(Integer.parseInt(codigo)); 
			
			ListarResponse lr = stub.listar(l); 
			System.out.println("Listar: "+lr.get_return());
			
			RequestDispatcher rd; 
			req.setAttribute("codigo", codigo);
			req.getRequestDispatcher("resposta.jsp").forward(req, resp);	
			
		} catch (AxisFault e) {
			e.printStackTrace();
		} catch (RemoteException e) {
			e.printStackTrace();
		}
	}

}
